#include <bits/stdc++.h>
using namespace std;

/* =================== ENGINE CORE =================== */
using Entity = int;
static Entity NEXT_ENTITY = 0;

/* =================== COMPONENTS =================== */
struct Position {
    int x, y;
};

struct Health {
    int hp;
};

struct Weapon {
    int damage;
    int range;
};

/* =================== ECS STORAGE =================== */
unordered_map<Entity, Position> positions;
unordered_map<Entity, Health> healths;
unordered_map<Entity, Weapon> weapons;

/* =================== SYSTEMS =================== */
class InputSystem {
public:
    char input;
    void poll() {
        cin >> input;
        input = tolower(input);
    }
};

class MovementSystem {
public:
    void update() {
        for (auto &[e, pos] : positions) {
            if (e != 0) continue; // player only

            if (currentInput == 'w') pos.x--;
            if (currentInput == 's') pos.x++;
            if (currentInput == 'a') pos.y--;
            if (currentInput == 'd') pos.y++;

            pos.x = max(0, min(9, pos.x));
            pos.y = max(0, min(9, pos.y));
        }
    }
};

class CombatSystem {
public:
    void update() {
        Entity player = 0;

        for (auto &[e, w] : weapons) {
            if (e != player) continue;

            if (currentInput == ' ') {
                for (auto &[enemy, hp] : healths) {
                    if (enemy == player) continue;

                    auto &pp = positions[player];
                    auto &ep = positions[enemy];

                    if (abs(pp.x - ep.x) <= w.range &&
                        abs(pp.y - ep.y) <= w.range) {
                        hp.hp -= w.damage;
                        break;
                    }
                }
            }
        }
    }
};

class RenderSystem {
public:
    void draw() {
        system("clear"); // Windows → cls
        char grid[10][10];
        memset(grid, '.', sizeof(grid));

        for (auto &[e, pos] : positions) {
            if (e == 0) grid[pos.x][pos.y] = 'P';
            else if (healths[e].hp > 0) grid[pos.x][pos.y] = 'E';
        }

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++)
                cout << grid[i][j] << ' ';
            cout << '\n';
        }

        cout << "\nHP: " << healths[0].hp << "\n";
    }
};

/* =================== GLOBAL INPUT =================== */
char currentInput;

/* =================== ENGINE =================== */
class Engine {
private:
    InputSystem input;
    MovementSystem movement;
    CombatSystem combat;
    RenderSystem render;
    bool running = true;

public:
    void init() {
        // Player
        Entity player = NEXT_ENTITY++;
        positions[player] = {5, 5};
        healths[player] = {100};
        weapons[player] = {20, 1};

        // Enemy
        for (int i = 0; i < 3; i++) {
            Entity e = NEXT_ENTITY++;
            positions[e] = {rand() % 10, rand() % 10};
            healths[e] = {50};
        }
    }

    void run() {
        while (running) {
            render.draw();

            input.poll();
            currentInput = input.input;

            if (currentInput == 'q') break;

            movement.update();
            combat.update();

            cleanup();
        }
    }

    void cleanup() {
        for (auto it = healths.begin(); it != healths.end();) {
            if (it->second.hp <= 0 && it->first != 0) {
                positions.erase(it->first);
                it = healths.erase(it);
            } else ++it;
        }
    }
};

/* =================== MAIN =================== */
int main() {
    Engine engine;
    engine.init();
    engine.run();
    return 0;
}
